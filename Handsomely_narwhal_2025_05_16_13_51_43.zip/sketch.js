let fazendeiro;
let cenouras = [];

function setup() {
  createCanvas(800, 400);
  
  // Inicializa o fazendeiro
  fazendeiro = {
    x: 50,
    y: 300,
    width: 30,
    height: 30,
    color: 'brown',
    speed: 2
  };

  // Inicializa as cenouras no campo
  cenouras.push({ x: 400, y: 250, width: 20, height: 50, color: 'orange' });
  cenouras.push({ x: 500, y: 200, width: 20, height: 50, color: 'orange' });
  cenouras.push({ x: 600, y: 150, width: 20, height: 50, color: 'orange' });
}

function draw() {
  background(135, 206, 250); // Cor do céu
  
  desenhaCenouras();
  desenhaFazendeiro();
  moverFazendeiro();
  colherCenoura();
  
  // Verifica se todas as cenouras foram colhidas
  if (cenouras.length === 0) {
    textSize(32);
    fill('green');
    text('Todas as cenouras foram colhidas!', 200, 200);
    noLoop(); // Para a animação após colher todas as cenouras
  }
}

// Função para desenhar o fazendeiro
function desenhaFazendeiro() {
  fill(fazendeiro.color);
  noStroke();
  rect(fazendeiro.x, fazendeiro.y, fazendeiro.width, fazendeiro.height);
}

// Função para desenhar as cenouras
function desenhaCenouras() {
  for (let cenoura of cenouras) {
    fill(cenoura.color);
    noStroke();
    rect(cenoura.x, cenoura.y, cenoura.width, cenoura.height);
  }
}

// Função para mover o fazendeiro
function moverFazendeiro() {
  if (fazendeiro.x < cenouras[0].x - 20) {
    fazendeiro.x += fazendeiro.speed; // Mover o fazendeiro para a direita
  }
}

// Função para "colher" a cenoura
function colherCenoura() {
  for (let i = cenouras.length - 1; i >= 0; i--) {
    let cenoura = cenouras[i];
    let distancia = dist(fazendeiro.x, fazendeiro.y, cenoura.x, cenoura.y);
    
    if (distancia < fazendeiro.width + cenoura.width / 2) {
      cenouras.splice(i, 1); // Remove a cenoura do campo
    }
  }
}
